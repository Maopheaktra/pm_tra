<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Throwable;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     *
     * @throws Throwable
     */
    public function run(): void
    {

    }
}
